import Grid from './Grid/Grid';

function App() {
  return (
    <Grid />
  );
}

export default App;
